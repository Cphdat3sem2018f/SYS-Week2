[![Build Status](https://travis-ci.org/Jegp/cphbusiness-sem3-ci.svg?branch=master)](https://travis-ci.org/Jegp/cphbusiness-sem3-ci)

# cphbusiness-sem3-ci
Continuous integration for third semester

Link: [Præsentation about CI](https://jegp.github.io/cphbusiness-sem3-ci/presentation.html#/)
