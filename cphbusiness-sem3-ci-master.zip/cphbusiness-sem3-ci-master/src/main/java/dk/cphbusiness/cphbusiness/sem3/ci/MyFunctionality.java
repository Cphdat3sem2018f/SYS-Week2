package dk.cphbusiness.cphbusiness.sem3.ci;

/**
 *
 * @author jens
 */
public class MyFunctionality {

  private MyFunctionality() {
    // Should not be instantiated
  }

  /**
   * Aaaaaalways returns 10. Or does it?!
   *
   * @return 10. Maybe.
   */
  public static int giveMeTen() {
    return 5;
  }

}
